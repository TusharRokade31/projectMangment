import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const signUp = createAsyncThunk(
    "signUp",
    async (signUpData,{rejectWithValue})=>{
        try {
            const {data} = await axios.post(
                `http://localhost:8002/users/sign-up`,
                signUpData
            )

            return data
        } catch (error) {
            return rejectWithValue(error);
        }
    }
)


export const loginUser = createAsyncThunk(
    "loginUser",
    async (loginData,{rejectWithValue})=>{
        try {
            const {data} = await axios.post(
                `http://localhost:8002/users/login`,
                loginData
            )

            return data
        } catch (error) {
            return rejectWithValue(error);
        }
    }
) 