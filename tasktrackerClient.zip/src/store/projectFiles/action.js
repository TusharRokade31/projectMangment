import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const getprojectFiles = createAsyncThunk(
  "getprojectFiles",
  async (ID, { rejectWithValue }) => {
    try {
      const { data } = await axios.get(
        `http://localhost:8002/projectfile/getproject-file/${ID}`
      );

      return data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const addProjectFile = createAsyncThunk(
  "addProjectFile",
  async (userdata, { rejectWithValue }) => {
    try {

      const { data } = await axios.post(
        `http://localhost:8002/projectfile/${userdata.student}/addproject-file`,
        userdata.data
      );

      return data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);
