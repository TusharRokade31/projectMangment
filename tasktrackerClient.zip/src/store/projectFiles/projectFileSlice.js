import { createSlice } from "@reduxjs/toolkit";
import { addProjectFile, getprojectFiles } from "./action";

const initialState = {
  projectFiles: [],
  message: "",
  isLoading: false,
  success: null,
  error: null,
};

const projectfileSlice = createSlice({
  name: "projectFiles",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(addProjectFile.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(addProjectFile.fulfilled, (state, action) => {
        state.isLoading = false;
        state.projectFiles.unshift(action.payload?.data);
      })
      .addCase(addProjectFile.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      .addCase(getprojectFiles.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getprojectFiles.fulfilled, (state, action) => {
        state.isLoading = false;
        state.projectFiles = action.payload?.data
      })
      .addCase(getprojectFiles.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
  },
});

export default projectfileSlice.reducer;
