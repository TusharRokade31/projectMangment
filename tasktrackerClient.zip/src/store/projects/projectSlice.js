import { createSlice } from "@reduxjs/toolkit";
import { addproject, getProject, getProjects, updateProject } from "./action";

const initialState = {
  projects: [],
  project: {},
  isLoading: false,
  success: null,
  error: null,
};


const projectSlice = createSlice({
    name:"project",
    initialState,
    reducers:{},
    extraReducers:(builder)=>{
        builder
        .addCase(addproject.pending,(state)=>{
            state.isLoading = true
        })
        .addCase(addproject.fulfilled,(state, action)=>{
            state.isLoading = false
            state.projects.unshift(action.payload)
        })
        .addCase(addproject.rejected,(state, action)=>{
            state.isLoading = false
            state.error = action.payload
        })
        .addCase(getProjects.pending,(state)=>{
            state.isLoading = true
        })
        .addCase(getProjects.fulfilled,(state, action)=>{
            state.isLoading = false
            state.projects = action.payload.data
        })
        .addCase(getProjects.rejected,(state, action)=>{
            state.isLoading = false
            state.error = action.payload
        })
        .addCase(getProject.pending,(state)=>{
            state.isLoading = true
        })
        .addCase(getProject.fulfilled,(state, action)=>{
            state.isLoading = false
            state.project = action.payload.data
        })
        .addCase(getProject.rejected,(state, action)=>{
            state.isLoading = false
            state.error = action.payload
        })
        .addCase(updateProject.pending, (state) => {
            state.isLoading = true;
          })
          .addCase(updateProject.fulfilled, (state, action) => {
            state.isLoading = false;
            const index = state.projects.findIndex(
              (p) => p._id === action.payload.data._id
            );
            if (index !== -1) {
              state.projects[index] = action.payload.data;
            }
            if (state.project._id === action.payload.data._id) {
              state.project = action.payload.data;
            }
          })
          .addCase(updateProject.rejected, (state, action) => {
            state.isLoading = false;
            state.error = action.payload;
          })
    }
})


export default projectSlice.reducer