import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const addproject = createAsyncThunk(
  "addproject",
  async ({ formData, studentID }, { rejectWithValue }) => {
    try {
      const { data } = await axios.post(
        `http://localhost:8002/projects/${studentID}/add-project`,
        formData
      );

      return data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const getProjects = createAsyncThunk(
  "getProjects",
  async (studentID, { rejectWithValue }) => {
    try {
      const { data } = await axios.post(
        `http://localhost:8002/projects/get-projects`,
        {
            studentID:studentID
        }
      );

      return data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);


export const getProject = createAsyncThunk(
    "getProject",
    async (projectID, { rejectWithValue }) => {
      try {
        const { data } = await axios.get(
          `http://localhost:8002/projects/get-project/${projectID}`,
          
        );
  
        return data;
      } catch (error) {
        return rejectWithValue(error);
      }
    }
  );


  export const updateProject = createAsyncThunk(
    "updateProject",
    async ({values, projectID}, { rejectWithValue }) => {
      try {
        const { data } = await axios.put(
          `http://localhost:8002/projects/update-project/${projectID}`,
          values
          
        );
  
        return data;
      } catch (error) {
        return rejectWithValue(error);
      }
    }
  );
  
