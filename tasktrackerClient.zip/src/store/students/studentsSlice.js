import { createSlice } from "@reduxjs/toolkit";
import { addStudent, getAllStudents, getStudent, getStudents, updateStudent } from "./action";

const initialState = {
  students: [],
  allstudents: [],
  student: {},
  message:"",
  isLoading: false,
  success: null,
  error: null,
};

const studentsSlice = createSlice({
  name: "students",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getStudents.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getStudents.fulfilled, (state, action) => {
        state.isLoading = false;
        state.students = action.payload.data;
      })
      .addCase(getStudents.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      .addCase(getAllStudents.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getAllStudents.fulfilled, (state, action) => {
        state.isLoading = false;
        state.allstudents = action.payload.data;
      })
      .addCase(getAllStudents.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      .addCase(getStudent.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getStudent.fulfilled, (state, action) => {
        state.isLoading = false;
        state.student = action.payload.data;
      })
      .addCase(getStudent.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      .addCase(addStudent.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(addStudent.fulfilled, (state, action) => {
        state.isLoading = false;
        if(action.payload.message !== "student already added..."){
          state.students.unshift(action.payload.data);
          state.message =  action.payload.message
        }else{
          state.message =  action.payload.message
        }
      })
      .addCase(addStudent.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      .addCase(updateStudent.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(updateStudent.fulfilled, (state, action) => {
        state.isLoading = false;
        const index = state.students.findIndex(
          (p) => p._id === action.payload.data._id
        );
        if (index !== -1) {
          state.students[index] = action.payload.data;
        }
        if (state.student._id === action.payload.data._id) {
          state.student = action.payload.data;
        }
      })
      .addCase(updateStudent.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
  },
});

export default studentsSlice.reducer;
