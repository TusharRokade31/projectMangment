import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const getStudents = createAsyncThunk(
    "getStudents",
    async ({ page, size, search },{rejectWithValue})=>{
        try {
            const {data} = await axios.get(
                `http://localhost:8002/students/get-search-students?page=${page}&size=${size}&search=${search}`
            )

            return data
        } catch (error) {
            return rejectWithValue(error);
        }
    }
) 


export const getAllStudents = createAsyncThunk(
    "getAllStudents",
    async (arg,{rejectWithValue})=>{
        try {
            const {data} = await axios.get(
                `http://localhost:8002/students/get-search-students`
            )

            return data
        } catch (error) {
            return rejectWithValue(error);
        }
    }
) 


export const getStudent = createAsyncThunk(
    "getStudent",
    async (studentID,{rejectWithValue})=>{
        try {
            const {data} = await axios.get(
                `http://localhost:8002/students/get-student/${studentID}`
            )

            return data
        } catch (error) {
            return rejectWithValue(error);
        }
    }
) 


export const updateStudent = createAsyncThunk(
    "updateStudent",
    async ({values, studentID},{rejectWithValue})=>{
        try {
            const {data} = await axios.put(
                `http://localhost:8002/students/update-student/${studentID}`,
                values
            )

            return data
        } catch (error) {
            return rejectWithValue(error);
        }
    }
) 


export const addStudent = createAsyncThunk(
    "addStudents",
    async (formData,{rejectWithValue})=>{
        try {
            const {data} = await axios.post(
                `http://localhost:8002/students/add-student`,
                formData
            )

            return data
        } catch (error) {
            return rejectWithValue(error);
        }
    }
) 