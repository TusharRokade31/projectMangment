import { configureStore } from "@reduxjs/toolkit";
import userReducer from "./users/userSlice";
import studentsReducer from "./students/studentsSlice";
import coursesReducer from "./courses/coursesSlice";
import projectReducer from "./projects/projectSlice";
import projectFilesReducer from "./projectFiles/projectFileSlice";
const store = configureStore({
    reducer: {
        userss: userReducer,
        studentss: studentsReducer,
        Coursess: coursesReducer,
        projectss: projectReducer,
        projectFiles: projectFilesReducer,
    },
  });

export default store;
