import { createSlice } from "@reduxjs/toolkit";
import { addCourse, deleteCourse, getCourses } from "./action";

const initialState = {
  courses: [],
  course: {},
  message:"",
  isLoading: false,
  success: null,
  error: null,
};

const studentsSlice = createSlice({
  name: "courses",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getCourses.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getCourses.fulfilled, (state, action) => {
        state.isLoading = false;
        state.courses = action.payload.data;
      })
      .addCase(getCourses.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      .addCase(addCourse.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(addCourse.fulfilled, (state, action) => {
        state.isLoading = false;
        if(action.payload.message !== "Course already exist!"){
          state.courses.unshift(action.payload.data);
          state.message =  action.payload.message
        }else{
          state.message =  action.payload.message
        }
        
      })
      .addCase(addCourse.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      .addCase(deleteCourse.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(deleteCourse.fulfilled, (state, action) => {
        state.isLoading = false;
        state.courses = state.courses.filter((item)=>{
          item._id !== action.payload.ID
        })
        state.message =  action.payload.message
      })
      .addCase(deleteCourse.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
  },
});

export default studentsSlice.reducer;
