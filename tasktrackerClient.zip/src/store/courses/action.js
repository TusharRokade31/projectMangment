import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const getCourses = createAsyncThunk(
    "getCourses",
    async (arg,{rejectWithValue})=>{
        try {
            const {data} = await axios.get(
                `http://localhost:8002/courses/get-courses`
            )

            return data
        } catch (error) {
            return rejectWithValue(error);
        }
    }
) 


export const addCourse = createAsyncThunk(
    "addCourse",
    async (formData,{rejectWithValue})=>{
        try {
            const {data} = await axios.post(
                `http://localhost:8002/courses/add-course`,
                formData
            )

            return data
        } catch (error) {
            return rejectWithValue(error);
        }
    }
) 


export const deleteCourse = createAsyncThunk(
    "deleteCourse",
    async (ID,{rejectWithValue})=>{
        try {
            const {data} = await axios.delete(
                `http://localhost:8002/courses/delete-course/${ID}`
            )

            return data
        } catch (error) {
            return rejectWithValue(error);
        }
    }
) 