import React, { useRef } from "react";
import { addproject } from "../store/projects/action";
import { useDispatch } from "react-redux";

const AddProjectForm = ({ studentID }) => {
  const dispatch = useDispatch();

  const title = useRef();
  const description = useRef();
  const startDate = useRef();
  const deadline = useRef();
  const status = useRef();
  const handleSubmit = (e) => {
    e.preventDefault();
   
    dispatch(
      addproject({
        formData: {
          title: title.current.value,
          description: description.current.value,
          startDate:startDate.current.value,
          deadline:deadline.current.value,
          status:status.current.value,
        },
        studentID: studentID,
      })
    );

    title.current.value = "";
    description.current.value = ""
    startDate.current.value = ""
    deadline.current.value = ""
    status.current.value = ""
    
  };
  return (
    <>
      <div className="rounded-lg bg-white p-8 lg:col-span-3 lg:p-8">
        <form action="#" className="space-y-4">
          <div className="text-base leading-1 space-y-4 text-gray-700">
            <div className="flex flex-col">
              <label className="leading-loose">Project Title</label>
              <input
                type="text"
                ref={title}
                className="px-4 py-2 border focus:ring-gray-500 focus:border-gray-900 w-full sm:text-sm border-gray-300 rounded-md focus:outline-none text-gray-600"
                placeholder="title"
              />
            </div>
            <div className="flex flex-col">
              <label className="leading-loose">Project Description</label>
              <textarea
                className="w-full focus:outline-none rounded-lg border border-gray-200 p-3 text-sm"
                ref={description}
                placeholder="Description"
              ></textarea>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex flex-col">
                <label className="leading-loose">Start</label>
                <div className="relative focus-within:text-gray-600 text-gray-400">
                  <input
                    type="date"
                    ref={startDate}
                    className="pr-4 pl-4 py-2 border focus:ring-gray-500 focus:border-gray-900 w-full sm:text-sm border-gray-300 rounded-md focus:outline-none text-gray-600"
                  />
                </div>
              </div>
              <div className="flex flex-col">
                <label className="leading-loose">End</label>
                <div className="relative focus-within:text-gray-600 text-gray-400">
                  <input
                    type="date"
                    ref={deadline}
                    className="pr-4 pl-4 py-2 border focus:ring-gray-500 focus:border-gray-900 w-full sm:text-sm border-gray-300 rounded-md focus:outline-none text-gray-600"
                  />
                </div>
              </div>
            </div>
            <div className="flex flex-col">
              <label className="leading-loose">Change Status</label>
              <select
                id="countries"
                ref={status}
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-6/12 p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
              >
                <option >Selected Current Status</option>
                <option defaultValue value="inProgress">InProgress</option>
                <option value="incomplete">InComplete</option>
                <option value="done">Done</option>
              </select>
            </div>
          </div>
          <div className="mt-4">
            <button
              type="submit"
              onClick={handleSubmit}
              className="inline-block w-full rounded-lg bg-black px-5 py-3 font-medium text-white sm:w-auto"
            >
              Submit
            </button>
          </div>
        </form>
      </div>
    </>
  );
};

export default AddProjectForm;
