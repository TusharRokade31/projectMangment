import moment from "moment";
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getprojectFiles } from "../store/projectFiles/action";

const DownloadProjectTable = ({ ID }) => {

  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(
      getprojectFiles(ID)
    );
  }, [dispatch,ID]);

  const project = useSelector((state) => state.projectFiles.projectFiles);
  console.log(project);
  return (
    <>
      {project.length !== 0 ? <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
      <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
         <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
          <tr>
            <th scope="col" className="px-6 py-3">
              Product name
            </th>
            <th scope="col" className="px-6 py-3">
              download ID
            </th>
            <th scope="col" className="px-6 py-3">
              upload Date
            </th>
            <th scope="col" className="px-6 py-3">
              <span className="sr-only">Download</span>
            </th>
          </tr>
        </thead> 
        <tbody>
          {project &&
            project.map((item) => {
              return (
                <tr
                  key={item._id}
                  className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"
                >
                  <th
                    scope="row"
                    className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                  >
                    {item.title}
                  </th>
                  <td className="px-6 py-4">{item._id}</td>
                  <td className="px-6 py-4">
                    {moment(item.createdAt).format("DD-MM-YYYY")}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <a
                      href={`http://localhost:8002/uploads/${item.file}`}
                      download
                      className="font-medium text-blue-600 dark:text-blue-500 hover:underline"
                    >
                      Download
                    </a>
                  </td>
                </tr>
              );
            })}
        </tbody>
      </table>
    </div>: <h2>No project Found</h2>}
    </>
  );
};

export default DownloadProjectTable;
