import React, { useState } from "react";
import { MdOutlineIncompleteCircle } from "react-icons/md";
import { useStateContext } from "../contexts/ContextProvider";
import EditProjectComplete from "./EditProjectComplete";

const CompleteTab = ({ projects }) => {
  const { comphandleShow } = useStateContext();
  const [formData, setFormData] = useState({});


  const handleEdit = (ID) => {
    comphandleShow();
    let singleProject = projects.find((project) => project._id === ID);
    setFormData(singleProject);
  };

  return (
    <>
      <div className="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow  dark:bg-gray-800 dark:border-gray-700">
        <h5 className="bg-slate-200 mb-3 text-base px-3 py-2 font-semibold text-gray-900 md:text-xl dark:text-white">
          Done
        </h5>
        <ul className="p-3">
          {projects?.length === 0 ? (
            <li>nothing</li>
          ) : (
            projects?.map((item) => {
              return (
                <li className="my-2" key={item._id}>
                  <div
                    onClick={() => handleEdit(item._id)}
                    className="flex items-center p-3 text-base font-bold text-gray-900 rounded-lg bg-gray-50 hover:bg-gray-100 group hover:shadow dark:bg-gray-600 dark:hover:bg-gray-500 dark:text-white"
                  >
                    <MdOutlineIncompleteCircle />
                    <span className="flex-1 ms-3 whitespace-nowrap">
                      {item.title}
                    </span>
                    <span className="inline-flex items-center justify-center px-2 py-0.5 ms-3 text-xs font-medium text-gray-500 bg-gray-200 rounded dark:bg-gray-700 dark:text-gray-400">
                      edit
                    </span>
                  </div>
                </li>
              );
            })
          )}
        </ul>
      </div>

      <EditProjectComplete singleProject={formData} />
    </>
  );
};

export default CompleteTab;
