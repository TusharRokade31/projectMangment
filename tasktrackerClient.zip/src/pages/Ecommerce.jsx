import React, { useEffect } from 'react';
import { IoIosMore } from 'react-icons/io';
import { DropDownListComponent } from '@syncfusion/ej2-react-dropdowns';

import { useDispatch, useSelector } from 'react-redux';

import { Button, LineChart } from '../components';
import { medicalproBranding, dropdownData,} from '../data/dummy';
import { useStateContext } from '../contexts/ContextProvider';
import { Link } from 'react-router-dom';
import { getAllStudents, } from '../store/students/action';
import { MdOutlineSupervisorAccount } from 'react-icons/md';
import { BsBoxSeam } from 'react-icons/bs';
import { FiBarChart } from 'react-icons/fi';
import { HiOutlineRefresh } from 'react-icons/hi';


const DropDown = ({ currentMode }) => (
  <div className="w-28 border-1 border-color px-2 py-1 rounded-md">
    <DropDownListComponent id="time" fields={{ text: 'Time', value: 'Id' }} style={{ border: 'none', color: (currentMode === 'Dark') && 'white' }} value="1" dataSource={dropdownData} popupHeight="220px" popupWidth="120px" />
  </div>
);

const Ecommerce = () => {
  const { currentColor, currentMode } = useStateContext();

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getAllStudents());
  }, [dispatch]);
  const student = useSelector((state) => state.studentss.allstudents);
  console.log(student)

  let totalProjects = 0;
let doneProjects = 0;
let inProgressProjects = 0;
let incompleteProjects = 0;



student.forEach(student => {
  const projects = student.projects;
  totalProjects += projects.length;
  
  projects.forEach(project => {
    if (project.status === 'done') {
      doneProjects++;
    } else if (project.status === 'inProgress') {
      inProgressProjects++;
    } else if (project.status === 'incomplete') {
      incompleteProjects++;
    }
  });
});

const totalpedingAndincomp = incompleteProjects + inProgressProjects
console.log(totalpedingAndincomp)




const earningData = [
    {
      icon: <MdOutlineSupervisorAccount />,
      amount: `${student.length}`,
      title: 'All Students',
      iconColor: '#03C9D7',
      iconBg: '#E5FAFB',
      pcColor: 'red-600',
    },
    {
      icon: <BsBoxSeam />,
      amount: `${totalProjects}`,
      title: 'Projects',
      iconColor: 'rgb(255, 244, 229)',
      iconBg: 'rgb(254, 201, 15)',
      pcColor: 'green-600',
    },
    {
      icon: <FiBarChart />,
      amount: `${doneProjects}`,
      title: 'Project Complete',
      iconColor: 'rgb(228, 106, 118)',
      iconBg: 'rgb(255, 244, 229)',
      pcColor: 'green-600',
    },
    {
      icon: <HiOutlineRefresh />,
      amount: `${totalpedingAndincomp}`,
      title: 'Pending',
      iconColor: 'rgb(0, 194, 146)',
      iconBg: 'rgb(235, 250, 242)',
      pcColor: 'red-600',
    },
  ];

  return (
    <div className="mt-20">
      <div className="flex flex-wrap lg:flex-nowrap justify-center ">
        <div className="flex m-3 justify-center gap-7 items-center">
          {earningData.map((item) => (
            <div key={item.title} className="bg-white  flex flex-col justify-center  items-center h-44 dark:text-gray-200 dark:bg-secondary-dark-bg md:w-64  p-4 pt-9 rounded-2xl ">
              <button
                type="button"
                style={{ color: item.iconColor, backgroundColor: item.iconBg }}
                className="text-2xl opacity-0.9 rounded-full  p-4 hover:drop-shadow-xl"
              >
                {item.icon}
              </button>
              <p className="mt-3">
                <span className="text-lg font-semibold">{item.amount}</span>
                <span className={`text-sm text-${item.pcColor} ml-2`}>
                  {item.percentage}
                </span>
              </p>
              <p className="text-sm text-gray-400  mt-1">{item.title}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="flex gap-10 m-4 lg:flex-nowrap flex-wrap justify-center">
        
        <div className="w-390 bg-white dark:text-gray-200 dark:bg-secondary-dark-bg rounded-2xl p-6 m-3">
          <div className="flex justify-between">
            <p className="text-xl font-semibold">Wrap-up</p>
            <button type="button" className="text-xl font-semibold text-gray-400">
              <IoIosMore />
            </button>
          </div>
          <p className="text-xs cursor-pointer hover:drop-shadow-xl font-semibold rounded-lg w-24 bg-orange-400 py-0.5 px-2 text-gray-200 mt-10">
            21 MAY, 2024
          </p>

          <div className="flex gap-4 border-b-1 border-color mt-6">
            {medicalproBranding.data.map((item) => (
              <div key={item.title} className="border-r-1 border-color pr-4 pb-2">
                <p className="text-xs text-gray-400">{item.title}</p>
                <p className="text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
          <div className="border-b-1 border-color pb-4 mt-2">
            <p className="text-md font-semibold mb-2">Recent</p>

            <div className="flex gap-4">
              {medicalproBranding.teams.map((item) => (
                <p
                  key={item.name}
                  style={{ background: item.color }}
                  className="cursor-pointer hover:drop-shadow-xl text-white py-0.5 px-3 rounded-lg text-xs"
                >
                  {item.name}
                </p>
              ))}
            </div>
          </div>
          <div className="mt-2">
            <p className="text-md font-semibold mb-2">Students</p>
            <div className="flex gap-4">
              {medicalproBranding.leaders.map((item, index) => (
                <img key={index} className="rounded-full w-8 h-8" src={item.image} alt="" />
              ))}
            </div>
          </div>
          <div className="flex justify-between items-center mt-5 border-t-1 border-color">
              <Link to={'/students'}>
              <div className="mt-3">
              <Button
                color="white"
                bgColor={currentColor}
                text="see all"
                borderRadius="10px"
              />
            </div>
              </Link>
          </div>
        </div>
        <div className="bg-white dark:text-gray-200 dark:bg-secondary-dark-bg p-6 rounded-2xl w-96 md:w-760">
          <div className="flex justify-between items-center gap-2 mb-10">
            <p className="text-xl font-semibold">Sales Overview</p>
            <DropDown currentMode={currentMode} />
          </div>
          <div className="md:w-full overflow-auto">
            <LineChart />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Ecommerce;
