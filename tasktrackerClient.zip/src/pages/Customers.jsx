import React, { useEffect, useState } from "react";
import { FaDotCircle } from "react-icons/fa";
import moment from "moment";
import { Header } from "../components";
import { useDispatch } from "react-redux";
import { getStudents } from "../store/students/action";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";

const Customers = () => {
  const dispatch = useDispatch();
  const [pageCount, Setpagecount] = useState(1);
  const [searchVal, setsearchVal] = useState("");

  const handleChange = (e) => {
    // console.log(e.target.value)
    setsearchVal(e.target.value);
  };

  useEffect(() => {
    dispatch(getStudents({ page: pageCount, size: "8", search: searchVal }));
  }, [searchVal, pageCount]);

  const data = useSelector((state) => state.studentss.students);
  // console.log(data);

  const custamizedata = data.map((obj) => ({
    ...obj,
    project: [
      {
        ...(obj.projects[obj.projects.length - 1] !== undefined
          ? obj.projects[obj.projects.length - 1]
          : ""),
      },
    ],
  }));


  return (
    <>
      <div className="m-2 md:m-10 mt-24 p-2 md:p-10 bg-white rounded-3xl">
        <div className="flex items-center justify-between">
          <Header category="Page" title="Students" />
          <div className="relative w-6/12">
            <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
              <svg
                className="w-4 h-4 text-gray-500 dark:text-gray-400"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 20 20"
              >
                <path
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
                />
              </svg>
            </div>
            <input
              type="search"
              id="default-search"
              onChange={handleChange}
              className="block focus:outline-none w-full p-4 ps-10 text-sm text-gray-900 border-gray-100 rounded-lg bg-gray-50 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white "
              placeholder="Search..."
            />
          </div>
        </div>
        <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
          <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
              <tr>
                <th scope="col" className="px-6 py-3">
                  Name
                </th>
                <th scope="col" className="px-6 py-3">
                  Email
                </th>
                <th scope="col" className="px-6 py-3">
                  Contact
                </th>
                <th scope="col" className="px-6 py-3">
                  Course
                </th>
                <th scope="col" className="px-6 py-3">
                  recent Project
                </th>
                <th scope="col" className="px-3 py-3">
                  project Status
                </th>
                <th scope="col" className="px-6 py-3">
                  Start Date
                </th>
                <th scope="col" className="px-6 py-3">
                  <span className="sr-only">Edit</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {custamizedata &&
                custamizedata.map((one) => {
                  return (
                    <tr
                      key={one._id}
                      className="bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-600"
                    >
                      <th
                        scope="row"
                        className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                      >
                        {one.fname} {one.lname}
                      </th>
                      <td className="px-4 py-4">{one.email}</td>
                      <td className="px-4 py-4">{one.contact}</td>
                      <td className="px-2 py-4">
                        {one.course?.courseName ? one.course?.courseName : "__"}
                      </td>
                      {one.project.map((project) => {
                        return (
                          <>
                            <td className="px-4 py-4">
                              {project.title ? project.title : "__"}
                            </td>
                            <td className="px-4 py-4">
                              <div className="flex items-center justify-items-center">
                                {project.status ? (
                                  <FaDotCircle className="text-lime-600 me-2" />
                                ) : (
                                  ""
                                )}
                                {project.status ? project.status : "__"}
                              </div>
                            </td>
                            <td className="py-4">
                              {project.title
                                ? moment(project.startDate).format("DD-MM-YYYY")
                                : "__"}
                            </td>
                          </>
                        );
                      })}

                      <td className="px-6 py-4 text-right">
                        <Link
                          to={`/studentprofile/${one._id}`}
                          className="font-medium text-blue-600 dark:text-blue-500 hover:underline"
                        >
                          <button
                            type="button"
                            className="text-white bg-gradient-to-r from-blue-400 via-blue-400 to-blue-400 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center me-2 mb-2"
                          >
                            view
                          </button>
                        </Link>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
          <div className="flex py-5 px-10">
            <a
              onClick={() => Setpagecount(pageCount - 1)}
              className="flex items-center justify-center px-3 h-8 me-3 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
            >
              <svg
                className="w-3.5 h-3.5 me-2 rtl:rotate-180"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 14 10"
              >
                <path
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M13 5H1m0 0 4 4M1 5l4-4"
                />
              </svg>
              Previous
            </a>
            <a
              onClick={() => Setpagecount(pageCount + 1)}
              className="flex items-center justify-center px-3 h-8 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
            >
              Next
              <svg
                className="w-3.5 h-3.5 ms-2 rtl:rotate-180"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 14 10"
              >
                <path
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M1 5h12m0 0L9 1m4 4L9 9"
                />
              </svg>
            </a>
          </div>
        </div>
      </div>
    </>
  );
};

export default Customers;
