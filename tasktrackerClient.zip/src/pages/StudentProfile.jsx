import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getStudent } from "../store/students/action";
import AddProjectForm from "../components/AddProjectForm";
import IncompleteTab from "../components/IncompleteTab";
import InprogressTab from "../components/InprogressTab";
import CompleteTab from "../components/CompleteTab";
import { getProjects } from "../store/projects/action";
import DownloadProjectTable from "../components/DownloadProjectTable";

const StudentProfile = () => {
  const dispatch = useDispatch();
  const { studentID } = useParams();

  useEffect(() => {
    dispatch(getProjects(studentID));
    dispatch(getStudent(studentID));
  }, []);
  const [activeTab, setActiveTab] = useState("Tab1");
  const student = useSelector((state) => state.studentss.student);
  console.log(student)
  const projects = useSelector((state) => state.projectss.projects);

  const inProgressProjects = projects?.filter(
    (project) => project.status === "inProgress"
  );

  const incompleteProjects = projects?.filter(
    (project) => project.status === "incomplete"
  );

  const completeProjects = projects?.filter(
    (project) => project.status === "done"
  );

  return (
    <>
      <div className="bg-white md:mx-auto rounded shadow-xl w-full md:w-10/12 overflow-hidden">
        <div className="h-[140px] bg-gradient-to-r from-cyan-500 to-blue-500"></div>
        <div className="px-5 py-2 flex flex-col gap-3 pb-6">
          <div className="h-[90px] shadow-md w-[90px] rounded-full border-4 overflow-hidden -mt-14 border-white">
            <img
              src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8YXZhdGFyfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60"
              className="w-full h-full rounded-full object-center object-cover"
            />
          </div>
          <div className="">
            <h3 className="text-xl text-slate-900 relative font-bold leading-6">
              {student.fname} {student.lname}
            </h3>
            <p className="text-sm text-gray-600">{student.email}</p>
          </div>
          <div className="flex gap-3 flex-wrap">
            <span className="rounded-sm bg-yellow-100 px-3 py-1 text-xs font-medium text-yellow-800">
              Developer
            </span>
            <span className="rounded-sm bg-green-100 px-3 py-1 text-xs font-medium text-green-800">
              Design
            </span>
            <span className="rounded-sm bg-blue-100 px-3 py-1 text-xs font-medium text-blue-800">
              Managements
            </span>
            <span className="rounded-sm bg-indigo-100 px-3 py-1 text-xs font-medium text-indigo-800">
              Projects
            </span>
          </div>
          <div className="flex gap-2">
          <Link to={`mailto:${student.email}`}>
            <button
              type="button"
              className="inline-flex w-auto cursor-pointer select-none appearance-none items-center justify-center space-x-1 rounded border border-gray-200 bg-white px-3 py-2 text-sm font-medium text-gray-800 transition hover:border-gray-300 active:bg-white hover:bg-gray-100 focus:border-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-300"
            >
              Send Email
            </button>
            </Link>

            <Link to={`/edit-student/${studentID}`}>
              <button
                type="button"
                className="inline-flex w-auto cursor-pointer select-none appearance-none items-center justify-center space-x-1 rounded border border-gray-200 bg-blue-700 px-3 py-2 text-sm font-medium text-white transition hover:border-blue-300 hover:bg-blue-600 active:bg-blue-700 focus:blue-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-300"
              >
                Edit Profile
              </button>
            </Link>
          </div>
          <h4 className="text-md font-medium leading-3">About</h4>
          <p className="text-sm text-stone-500">
          Hello! My name is {student.fname} {student.lname}, and I am currently pursuing a {student.course?.courseName} course at Try Catch Classes. With a strong passion for learning and a commitment to excellence, I am dedicated to making the most of my educational journey.
          </p>
          

          <div>
            <nav className="flex border-b border-gray-200">
              <button
                className={`px-4 py-2 -mb-px border-b-2 ${
                  activeTab === "Tab1"
                    ? "border-blue-500 text-blue-500"
                    : "border-transparent text-gray-500"
                }`}
                onClick={() => setActiveTab("Tab1")}
              >
                Projects
              </button>
              <button
                className={`px-4 py-2 -mb-px border-b-2 ${
                  activeTab === "Tab2"
                    ? "border-blue-500 text-blue-500"
                    : "border-transparent text-gray-500"
                }`}
                onClick={() => setActiveTab("Tab2")}
              >
                Add Project
              </button>
              <button
                className={`px-4 py-2 -mb-px border-b-2 ${
                  activeTab === "Tab3"
                    ? "border-blue-500 text-blue-500"
                    : "border-transparent text-gray-500"
                }`}
                onClick={() => setActiveTab("Tab3")}
              >
                Download Files
              </button>
            </nav>
            <div className="p-4">
              {activeTab === "Tab1" && (
                <div className="flex items-start">
                  <InprogressTab projects={inProgressProjects} />
                  <IncompleteTab projects={incompleteProjects} />
                  <CompleteTab projects={completeProjects} />
                </div>
              )}
              {activeTab === "Tab2" && (
                <div>
                  <AddProjectForm studentID={student._id} />
                </div>
              )}
              {activeTab === "Tab3" && (
                <div>
                  <DownloadProjectTable ID={student._id} />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default StudentProfile;
