import React, { useEffect, useState } from "react";
import { Header } from "../components";
import { getStudent, updateStudent } from "../store/students/action";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import { getCourses } from "../store/courses/action";

const EditStudent = () => {
    const dispatch = useDispatch();
  const { studentID } = useParams();
  const Navigate = useNavigate()

  useEffect(() => {
    dispatch(getCourses());
    
    dispatch(getStudent(studentID));
  }, []);
  const course = useSelector((state) => state.Coursess.courses);
  const student = useSelector((state) => state.studentss.student);

  const [formData, setFormData] = useState({
    fname: student.fname,
    lname: student.lname,
    email: student.email,
    course: student?.course?._id,
    contact: student.contact,
  });


  useEffect(() => {
    if (student) {
        setFormData({
        fname: student.fname,
        lname: student.lname,
        email: student.email,
        course: student?.course?._id,
        contact: student.contact,
      });
    }
  }, [student]);

  

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(updateStudent({values: formData, studentID:student._id}));
    Navigate(`/studentprofile/${studentID}`)
  };
  return (
    <div className="min-h-screen p-6 bg-gray-50 flex items-center justify-center">
      <div className="m-2 md:m-10 p-2 md:p-10 bg-white rounded-3xl">
      <div className="flex items-center justify-between">
        <Header category="Page" title="Edit Student" />
       
        </div>

        <div className="container max-w-screen-lg mx-auto">
          <div className="bg-white rounded shadow-lg p-4 px-4 md:p-8 mb-6">
            <div className="grid gap-4 gap-y-2 text-sm grid-cols-1 lg:grid-cols-3">
              <div className="text-gray-600">
                <p className="font-medium text-lg">Personal Details</p>
                <p>Please fill out all the fields.</p>
              </div>

              <div className="lg:col-span-2">
                <form onSubmit={handleSubmit}>
                  <div className="grid gap-4 gap-y-2 text-sm grid-cols-1 md:grid-cols-5">
                    <div className="md:col-span-3">
                      <label htmlFor="fname">First Name</label>
                      <input
                        type="text"
                        name="fname"
                        value={formData.fname}
                        onChange={handleChange}
                        id="fname"
                        className="focus:outline-none h-10 border mt-1 rounded px-4 w-full bg-gray-50"
                        placeholder="First Name"
                      />
                      </div>
                      <div className="md:col-span-2">
                      <label htmlFor="lname">Last Name</label>
                      <input
                        type="text"
                        name="lname"
                        value={formData.lname}
                        onChange={handleChange}
                        id="lname"
                        className="focus:outline-none h-10 border mt-1 rounded px-4 w-full bg-gray-50"
                        placeholder="Last Name"
                      />
                    </div>

                    <div className="md:col-span-5">
                      <label htmlFor="email">Email Address</label>
                      <input
                        type="text"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        id="email"
                        className="focus:outline-none h-10 border mt-1 rounded px-4 w-full bg-gray-50"
                        placeholder="email@address.com"
                      />
                    </div>

                    <div className="md:col-span-3">
                    <label htmlFor="course">Course</label>
                      <select
                        id=""
                        type="text"
                        name="course"
                        value={formData.course}
                        onChange={handleChange}
                        className="focus:outline-none h-10 border mt-1 rounded px-4 w-full bg-gray-50"
                      >
                        {course.length > 0 ? (
                          <>
                            <option>Select Course</option>
                            {course.map((courseItem, index) => (
                              <option key={index} value={courseItem._id}>
                                {courseItem.courseName.toUpperCase()}
                              </option>
                            ))}
                          </>
                        ) : (
                          <>
                            <option>Select Course</option>
                            <option disabled>
                              Course is not available first add course in course
                              page, then select from here.
                            </option>
                          </>
                        )}
                      </select>
                      
                    </div>

                    <div className="md:col-span-2">
                      <label htmlFor="contact">Contact</label>
                      <input
                        type="number"
                        name="contact"
                        value={formData.contact}
                        onChange={handleChange}
                        id="contact"
                        className="focus:outline-none h-10 border mt-1 rounded px-4 w-full bg-gray-50"
                        placeholder="Phone Number"
                      />
                    </div>

                    <div className="md:col-span-5 text-right">
                      <div className="inline-flex items-end">
                      <button
                          type="button"
                          onClick={()=>Navigate(`/studentprofile/${studentID}`)}
                          className="bg-blue-500 mx-2 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                        >
                          Back
                        </button>
                        <button
                          type="submit"
                          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                        >
                          Submit
                        </button>
                        
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditStudent;
