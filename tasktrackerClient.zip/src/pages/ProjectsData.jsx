import React, { useState } from 'react';
import { Accordion } from 'react-bootstrap';

const ProjectsData = () => {
    const [activeKey, setActiveKey] = useState('0');

  const handleSelect = (eventKey) => {
    setActiveKey(eventKey === activeKey ? null : eventKey);
  };

  return (
    <>
    <Accordion activeKey={activeKey} onSelect={handleSelect} className="custom-accordion">
      <Accordion.Item eventKey="0">
        <Accordion.Header>Accordion Item #1</Accordion.Header>
        <Accordion.Body>
          Content for Accordion Item #1
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="1">
        <Accordion.Header>Accordion Item #2</Accordion.Header>
        <Accordion.Body>
          Content for Accordion Item #2
        </Accordion.Body>
      </Accordion.Item>
    </Accordion></>
  )
}

export default ProjectsData