import courseModel from "../models/course.model.js";

export const getCourses = async (req, res) => {
    try {
        const courses = await courseModel.find({ status: 1 }).sort({ createdAt: -1 });
        if (courses) {
            return res.status(200).json({
                data: courses,
                message: "fetched"
            })
        }

    } catch (error) {
        return res.status(500).json({
            message: error.message
        })

    }
} 

export const addCourse = async (req, res) => {
    try {
        const { courseName } = req.body;
        const existCourse = await courseModel.findOne({ courseName: courseName });
        if (existCourse) {
            return res.status(200).json({ 
                message: "Course already exist!"
            })
        } 

        const course = await courseModel.create({
            ...req.body,
          });

          if (course) {
            return res.status(201).json({
              data: course,
              message: "Created",
            });
          }
    } catch (error) {
        return res.status(500).json({
            message: error.message
        })

    }

}

export const getCourse = async (req, res) => {
    try {
        const courseID = req.params.course_id;
        const course = await courseModel.findOne({ _id: courseID });
        if (course) {
            return res.status(200).json({
                data: course,
                message: "fetched"
            })
        }

        return res.status(400).json({
            message: "Bad Request"
        })

    } catch (error) {
        return res.status(500).json({
            message: error.message
        })

    }
}

export const updateCourse = async (req, res) => {
    try {
        const courseID = req.params.course_id;
        const { courseName, description } = req.body;
        const update_course = await courseModel.updateOne({ _id: courseID }, {
            $set: {
                courseName: courseName,
                description: description,
            }
        })
        if (update_course.acknowledged) {
            return res.status(200).json({
                message: "Updated"
            })

        }

        return res.status(400).json({
            message: "Bad Request"
        })

    } catch (error) {
        return res.status(500).json({
            message: error.message
        })

    }
}


export const deleteCourse = async (req, res) => {
    try {
        const courseID = req.params.course_id;
        const del_course = await courseModel.deleteOne({ _id: courseID })
        if (del_course.acknowledged) {
            return res.status(200).json({
                ID:courseID,
                data: del_course,
                message: "Deleted"

            })
        }

        return res.status(400).json({
            message: "Bad Request"
        })

    } catch (error) {
        return res.status(500).json({
            message: error.message
        })
    }
}
