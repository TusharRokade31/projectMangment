import multer from "multer";
import { storage } from "../util/fileUpload.js";
import path from "path";
import projectFileModel from "../models/projectFile.model.js";
import studentsModel from "../models/students.model.js";

const upload = multer({
  storage: storage,
  fileFilter: function (req, file, cb) {
    const fileTypes = /zip/;
    const extname = fileTypes.test(
      path.extname(file.originalname).toLowerCase()
    );
    if (extname) {
      return cb(null, true);
    } else {
      cb(new Error("Only .zip files are allowed!"));
    }
  },
});

export const addProjectFile = async (req, res) => {
  try {
    const { studentId } = req.params;
    const uploadMiddleware = upload.single("file");

    uploadMiddleware(req, res, async function (err) {
      if (err) {
        return res.status(400).json({
          message: err.message,
        });
      }

      let file = null;

      if (req.file) {
        file = req.file.filename;
      }

      const { title} = req.body;

      const studentData = await studentsModel.findById(studentId);
      if (!studentData) {
        return res.status(404).json({ message: "Student not found" });
      }


      const projectFile = new projectFileModel({
        title,
        student: studentData._id,
        file,
      }); 
  
      await projectFile.save();
      studentData.projectFiles.push(projectFile._id);
      await studentData.save();

      if (projectFile) {
        return res.status(201).json({
          data: projectFile,
          message: "Created",
        });
      } else {
        return res.status(400).json({
          message: "Failed to create project file",
        });
      }
    });
  } catch (error) {
    return res.status(500).json({
      message: error.message,
    });
  }
};

export const getProjectFiles = async (req, res) => {
  try {
    const { studentID } = req.params;
    const projectsFile = await projectFileModel
      .find({ student: studentID })
      .sort({ createdAt: -1 });
    if (projectsFile) {
      return res.status(200).json({
        data: projectsFile,
        message: "fetched",
      });
    }
  } catch (error) {
    return res.status(500).json({
      message: error.message,
    });
  }
};
