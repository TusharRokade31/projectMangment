import studentsModel from "../models/students.model.js";

export const addStudent = async (req, res) => {
  try {
    const { email } = req.body;

    const existstudent = await studentsModel.findOne({ email: email });
    if (existstudent) {
      return res.status(200).json({
        message: "student already added...",
      });
    }

    const student = await studentsModel.create({
      ...req.body,
    });

    if (student) {
      return res.status(201).json({
        data: student,
        message: "Created",
      });
    }
  } catch (error) {
    return res.status(500).json({
      message: error.message,
    });
  }
};

export const updateStudent = async (req, res) => {
  try {
    const studentID = req.params.student_id;
    const { fname, lname, course, email, contact } = req.body;

    const updateStudent = await studentsModel.updateOne(
      { _id: studentID },
      {
        $set: {
          fname: fname,
          lname: lname,
          email: email,
          contact: contact,
          course: course,
        },
      }
    );

    const student = await studentsModel.findOne({ _id: studentID });

    if (updateStudent.acknowledged) {
      return res.status(200).json({
        data: student,
        message: "Update",
      });
    }
  } catch (error) {
    return res.status(500).json({
      message: error.message,
    });
  }
};

export const getStudent = async (req, res) => {
  try {
    const studentID = req.params.student_id;
    const student = await studentsModel
      .findOne({ _id: studentID })
      .populate("course")
      .populate("projects")
      .populate("projectFiles")


    if (student) {
      return res.status(200).json({
        data: student,
        message: "fetched",
      });
    }

    return res.status(400).json({
      message: "Bad Request",
    });
  } catch (error) {
    return res.status(500).json({
      message: error.message,
    });
  }
};

export const getSearchStudents = async (req, res) => {
  try {
    const { page, size, search } = req.query;

    const skipno = (page - 1) * size;

    const rgx = (pattern) => new RegExp(`.*${pattern}.*`);
    const searchRgx = rgx(search);

    let filter = { status: 1 };
    if (search) {
      filter = {
        ...filter, 
        $or: [
          { fname: { $regex: searchRgx, $options: "i" } },
          { lname: { $regex: searchRgx, $options: "i" } },
          { email: { $regex: searchRgx, $options: "i" } },
        ],
      };
    }

    const students = await studentsModel
      .find(filter)
      .populate("course")
      .populate("projects")
      .populate("projectFiles")
      .limit(size)
      .skip(skipno)
      .sort({ createdAt: -1 });
    if (students) {
      return res.status(200).json({
        data: students,
        total: students.length,
        message: "Fetched",
      });
    }
  } catch (error) {
    return res.status(500).json({
      message: error.message,
    });
  }
};
