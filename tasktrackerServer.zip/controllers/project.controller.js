import projectModel from "../models/project.model.js";
import studentsModel from "../models/students.model.js";

export const addProject = async (req, res) => {
  try {
    const { studentId } = req.params;
    const { title, description, startDate, deadline, status } = req.body;

    const student = await studentsModel.findById(studentId);
    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }

    const project = new projectModel({
      title,
      description,
      student: student._id,
      startDate: startDate,
      deadline: deadline,
      status: status,
    });

    await project.save();

    student.projects.push(project._id);
    await student.save();

    res.status(201).json(project);
  } catch (error) {
    return res.status(500).json({
      message: error.message,
    });
  }
};

export const updateProject = async (req, res) => { 
  try {
    const projectID = req.params.projectId;
    const { title, description, status, startDate, deadline } = req.body;
    const update_project = await projectModel.updateOne(
      { _id: projectID },
      {
        $set: {
          title: title,
          description: description,
          status: status,
          startDate: startDate,
          deadline: deadline,
        },
      }
    );
    const project = await projectModel
      .findOne({ _id: projectID })
    if (update_project.acknowledged) {
      return res.status(200).json({ data: project, message: "Updated" });
    }
    return res.status(400).json({ message: "Bad request" });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

export const getProjects = async (req, res) => {
  try {
    const { studentID } = req.body;
    const projects = await projectModel
      .find({ student: studentID })
      .sort({ createdAt: -1 });
    if (projects) {
      return res.status(200).json({
        data: projects,
        message: "fetched",
      });
    }
  } catch (error) {
    return res.status(500).json({
      message: error.message,
    });
  }
};

export const getProject = async (req, res) => {
  try {
    const projectID = req.params.project_id;
    const project = await projectModel.findOne({ _id: projectID });

    if (project) {
      return res.status(200).json({
        data: project,
        message: "fetched",
      });
    }

    return res.status(400).json({
      message: "Bad Request",
    });
  } catch (error) {
    return res.status(500).json({
      message: error.message,
    });
  }
};
