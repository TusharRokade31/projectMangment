import usersModel from "../models/users.model.js";
import projectModel from "../models/project.model.js";
import studentsModel from "../models/students.model.js";


import jwt from "jsonwebtoken"

export const SignUp = async (req, res) => {
  try {
    const { fname, lname, email, password } = req.body;

    const existUser = await usersModel.findOne({ email: email });

    if (existUser) {
      return res.status(200).json({
        message: "user already exist",
      });
    }

    const saveUser = new usersModel({
      fname: fname,
      lname: lname,
      email: email,
      password: password,
    });

    saveUser.save();

    if (saveUser) {
      return res.status(201).json({
        data: saveUser,
        message: "Sign up Succssesfully",
      });
    }
  } catch (error) {
    return res.status(500).json({
      message: error.message,
    });
  }
};




export const login = async (req, res) => {
    try {
      const { email, password } = req.body;
  
      const existUser = await usersModel.findOne({ email: email });
      if (!existUser) {
        return res.status(400).json({
          message: "user not exist...",
        });
      }
  
  
      if (password !== existUser.password) {
        return res.status(400).json({
          message: "invalid credential",
        });
      }
  
      const token = jwt.sign(
        {
          id: existUser._id,
          email: existUser.email,
        },
        process.env.TOKEN_SECRET_KEY,
  
        { expiresIn: "1h" }
      );
    
      return res.status(200).json({
        data: existUser,
        token: token,
        message: "login Succsesfully",
      });
    } catch (error) {
      return res.status(500).json({
        message: error.message,
      });
    }
  };
