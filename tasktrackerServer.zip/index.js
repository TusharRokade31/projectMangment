import dotenv from 'dotenv';
dotenv.config();
import express from "express";
import cookieParser from 'cookie-parser';
import mongoose from "mongoose";
import userRouter from "./routers/users.router.js";
import studentRouter from "./routers/students.router.js";
import coursesRouter from "./routers/courses.router.js";
import projectRouter from "./routers/project.router.js";
import projectFileRouter from "./routers/projectFile.router.js";
import cors from "cors";

import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = 8002;

app.use(express.static(__dirname));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors({
  credentials: true,
}));
app.use(cookieParser());

app.listen(port, () => {
  console.log("Task Tracker's server is created...");
});

mongoose
  .connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/task-tracker-database")
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.log("Failed to connect to MongoDB", err));

app.get("/", (req, res) => {
  res.send("server is running...");
});

app.use("/users", userRouter);
app.use("/students", studentRouter);
app.use("/courses", coursesRouter);
app.use("/projects", projectRouter);
app.use("/projectfile", projectFileRouter);
