import mongoose from "mongoose";
import studentsModel from "./students.model.js";
import courseModel from "./course.model.js";

const Schema = mongoose.Schema;

const ProjectSchema = new Schema({
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  status: {
    type: String,
    enum: ['inProgress', 'incomplete', 'done'],
    default: 'inProgress',
  },
  deadline: {
    type: Date, 
    default:null
  },
  startDate: {
    type: Date, 
    default:null 
  },
  student: {
    type: Schema.Types.ObjectId,
    ref: studentsModel,
    required: true,
  },
  
  createdAT:{
    type:Date,
    default:Date.now()
  }
});

export default mongoose.model("project", ProjectSchema);
