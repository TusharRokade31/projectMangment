import mongoose from "mongoose";
import studentsModel from "./students.model.js";

const Schema = mongoose.Schema;

const ProjectFileSchema = new Schema({
  title:{
    type:String,
    required:true
  },
  file: {
    type: String,
    default: null,
  },
  status: {
    type: Number,
    default: 1,
  },
  student: {
    type: Schema.Types.ObjectId,
    ref: studentsModel,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
});

export default mongoose.model("projectFile", ProjectFileSchema);
