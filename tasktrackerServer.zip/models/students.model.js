import mongoose from "mongoose";
import courseModel from "./course.model.js";
import projectModel from "./project.model.js";

const Schema = mongoose.Schema;

const studentScehma = new Schema({
  fname: {
    type: String,
    required: true,
  },
  lname: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  contact: {
    type: Number,
    required: true,
  },
  course: {
    type: Schema.Types.ObjectId,
    default: null,
    ref: courseModel,
  },
  projects: [
    {
      type: Schema.Types.ObjectId,
      default: null,
      ref: "project",
    },
  ],
  projectFiles: [
    {
      type: Schema.Types.ObjectId,
      default: null,
      ref: "projectFile",
    },
  ],
  image: {
    type: String,
    default: null,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  status: {
    type: Number,
    default: 1,
  },
});

export default mongoose.model("student", studentScehma);
