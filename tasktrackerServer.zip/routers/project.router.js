import express from 'express'
import { addProject, getProject, getProjects, updateProject } from '../controllers/project.controller.js'

const  router = express.Router()

router.post('/:studentId/add-project', addProject)
router.get('/get-project/:project_id', getProject)
router.post('/get-projects', getProjects)
router.put('/update-project/:projectId', updateProject)

export default router