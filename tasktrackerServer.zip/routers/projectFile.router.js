import express from "express"
import { addProjectFile, getProjectFiles } from "../controllers/projectFile.controller.js"

const Router = express.Router()

Router.post("/:studentId/addproject-file", addProjectFile)
Router.get("/getproject-file/:studentID", getProjectFiles)


export default Router