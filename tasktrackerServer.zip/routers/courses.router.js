import express from "express"
import { addCourse, deleteCourse, getCourses, getCourse, updateCourse } from "../controllers/course.controller.js";

const router = express.Router();

router.get("/get-courses",getCourses);
router.post("/add-course",addCourse);
router.get("/get-course/:course_id",getCourse);
router.put("/update-course/:course_id", updateCourse);
router.delete("/delete-course/:course_id",deleteCourse);

export default router