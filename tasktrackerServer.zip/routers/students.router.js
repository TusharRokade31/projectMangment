import express from 'express'
import { addStudent, getSearchStudents, getStudent, updateStudent } from '../controllers/students.controller.js'

const  router = express.Router()

router.post('/add-student', addStudent)
router.get("/get-student/:student_id",getStudent);
router.put("/update-student/:student_id",updateStudent);
router.get('/get-search-students', getSearchStudents)

export default router