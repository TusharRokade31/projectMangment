import express from "express"
import { SignUp, login } from "../controllers/users.controller.js"

const router = express.Router()

router.post("/sign-up", SignUp)
router.post("/login", login)


export default router